# สมุดจดของ research-method
