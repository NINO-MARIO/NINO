# สมุดจดของ thai-text
