# สมุดจดของ skill-writer
