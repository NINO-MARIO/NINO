# สมุดจดของ notebook-keeping
