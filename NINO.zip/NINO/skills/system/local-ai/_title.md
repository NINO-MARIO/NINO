Local AI
