# สมุดจดของ code-analysis
